
import argparse
import csv
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree


EARTH_RADIUS = 6_371_000.0
DEFAULT_RADIUS = 100.0
ZERO_LENGTH_SQUARED = 1e-12

FEATURE_COLUMNS = [
    "distance_to_arc",
    "perpendicular_distance",
    "distance_to_arc_start",
    "distance_to_arc_end",
    "projection_fraction",
    "arc_length",
    "arc_heading",
    "gps_heading",
    "heading_difference",
    "gps_speed",
    "gps_displacement",
    "time_difference",
]

OUTPUT_COLUMNS = [
    "trip_id",
    "gps_id",
    "arc_id",
    *FEATURE_COLUMNS,
]


def load_data(path, expected_columns):
    data = np.loadtxt(path, dtype=float, ndmin=2)

    if data.size == 0 or data.shape[1] != expected_columns:
        raise ValueError(
            f"Invalid data in {path}: expected {expected_columns} columns"
        )

    if not np.all(np.isfinite(data)):
        raise ValueError(f"Non-finite values found in {path}")

    return data


def project_coordinates(lon, lat, origin_lon, origin_lat):
    """Local equirectangular projection to metres."""
    x = (
        np.radians(lon - origin_lon)
        * EARTH_RADIUS
        * np.cos(np.radians(origin_lat))
    )
    y = np.radians(lat - origin_lat) * EARTH_RADIUS
    return np.column_stack((x, y))


def bearing(vector):
    """Bearing in degrees clockwise from north."""
    if np.linalg.norm(vector) < 1e-12:
        return np.nan

    angle = np.degrees(np.arctan2(vector[0], vector[1]))
    return angle % 360.0


def angle_difference(a, b):
    if not np.isfinite(a) or not np.isfinite(b):
        return np.nan

    return abs((a - b + 180.0) % 360.0 - 180.0)


def build_gps_features(track_xy, timestamps):
    count = len(track_xy)

    headings = np.full(count, np.nan)
    speeds = np.full(count, np.nan)
    displacements = np.full(count, np.nan)
    time_differences = np.full(count, np.nan)

    for i in range(1, count):
        displacement_vector = track_xy[i] - track_xy[i - 1]
        displacement = np.linalg.norm(displacement_vector)
        dt = timestamps[i] - timestamps[i - 1]

        if dt <= 0:
            raise ValueError("GPS timestamps must be strictly increasing")

        displacements[i] = displacement
        time_differences[i] = dt
        speeds[i] = displacement / dt
        headings[i] = bearing(displacement_vector)

    return headings, speeds, displacements, time_differences


def enrich_dataset(dataset_path, radius):
    dataset_path = Path(dataset_path)
    trip_id = dataset_path.name

    track_file = dataset_path / f"{trip_id}.track"
    nodes_file = dataset_path / f"{trip_id}.nodes"
    arcs_file = dataset_path / f"{trip_id}.arcs"

    for file in (track_file, nodes_file, arcs_file):
        if not file.is_file():
            raise FileNotFoundError(f"Missing required file: {file}")

    track = load_data(track_file, 3)
    nodes = load_data(nodes_file, 2)
    arcs = load_data(arcs_file, 2).astype(np.int64)

    if len(track) == 0 or len(nodes) == 0 or len(arcs) == 0:
        raise ValueError("Track, nodes and arcs must not be empty")

    if np.any(arcs < 0) or np.any(arcs >= len(nodes)):
        raise ValueError("Arc references an invalid node ID")

    # Establish a local metric coordinate system.
    origin_lon = float(np.mean(nodes[:, 0]))
    origin_lat = float(np.mean(nodes[:, 1]))

    nodes_xy = project_coordinates(
        nodes[:, 0], nodes[:, 1], origin_lon, origin_lat
    )

    track_xy = project_coordinates(
        track[:, 0], track[:, 1], origin_lon, origin_lat
    )

    timestamps = track[:, 2]

    if np.any(np.diff(timestamps) <= 0):
        raise ValueError("Track timestamps must be strictly increasing")

    # Precompute static road arc geometry.
    starts = nodes_xy[arcs[:, 0]]
    ends = nodes_xy[arcs[:, 1]]
    vectors = ends - starts

    lengths = np.linalg.norm(vectors, axis=1)
    lengths_squared = np.einsum("ij,ij->i", vectors, vectors)

    arc_headings = np.array([bearing(v) for v in vectors])

    midpoints = (starts + ends) / 2.0

    # Candidate lookup using arc midpoints.
    tree = cKDTree(midpoints)
    search_radius = radius + float(np.max(lengths)) / 2.0

    # Dynamic GPS features.
    (
        gps_headings,
        gps_speeds,
        gps_displacements,
        gps_time_differences,
    ) = build_gps_features(track_xy, timestamps)

    output_file = dataset_path / f"{trip_id}.enrich.csv"

    candidate_counts = []
    total_rows = 0

    with output_file.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=OUTPUT_COLUMNS)
        writer.writeheader()

        for gps_id, point in enumerate(track_xy):
            possible_arcs = tree.query_ball_point(
                point, search_radius
            )

            candidate_count = 0

            for arc_id in possible_arcs:
                start = starts[arc_id]
                vector = vectors[arc_id]
                offset = point - start

                length_squared = lengths_squared[arc_id]

                if length_squared < ZERO_LENGTH_SQUARED:
                    fraction_raw = 0.0
                    perpendicular_distance = float(
                        np.linalg.norm(offset)
                    )
                else:
                    fraction_raw = float(
                        np.dot(offset, vector) / length_squared
                    )

                    cross = (
                        vector[0] * offset[1]
                        - vector[1] * offset[0]
                    )

                    perpendicular_distance = abs(cross) / np.sqrt(
                        length_squared
                    )

                projection_fraction = float(
                    np.clip(fraction_raw, 0.0, 1.0)
                )

                projection = (
                    start + projection_fraction * vector
                )

                distance_to_arc = float(
                    np.linalg.norm(point - projection)
                )

                # Retain only candidates within the configured radius.
                if distance_to_arc > radius:
                    continue

                distance_to_start = float(
                    np.linalg.norm(point - start)
                )
                distance_to_end = float(
                    np.linalg.norm(point - ends[arc_id])
                )

                heading_diff = angle_difference(
                    gps_headings[gps_id],
                    arc_headings[arc_id],
                )

                writer.writerow({
                    "trip_id": trip_id,
                    "gps_id": gps_id,
                    "arc_id": int(arc_id),
                    "distance_to_arc": distance_to_arc,
                    "perpendicular_distance": perpendicular_distance,
                    "distance_to_arc_start": distance_to_start,
                    "distance_to_arc_end": distance_to_end,
                    "projection_fraction": projection_fraction,
                    "arc_length": float(lengths[arc_id]),
                    "arc_heading": arc_headings[arc_id],
                    "gps_heading": gps_headings[gps_id],
                    "heading_difference": heading_diff,
                    "gps_speed": gps_speeds[gps_id],
                    "gps_displacement": gps_displacements[gps_id],
                    "time_difference": gps_time_differences[gps_id],
                })

                candidate_count += 1
                total_rows += 1

            candidate_counts.append(candidate_count)

    observations_without_candidates = sum(
        count == 0 for count in candidate_counts
    )

    average_candidates = (
        total_rows / len(track) if len(track) else 0.0
    )

    print(f"\nProcessed: {trip_id}")
    print(f"  GPS observations: {len(track)}")
    print(f"  Road nodes: {len(nodes)}")
    print(f"  Road arcs: {len(arcs)}")
    print(f"  Candidate rows: {total_rows}")
    print(f"  Average candidates per observation: {average_candidates:.2f}")
    print(f"  Observations without candidates: {observations_without_candidates}")
    print(f"  Output: {output_file}")

    return output_file


def find_datasets(root):
    root = Path(root)

    if not root.is_dir():
        print(f"[SKIP] Dataset directory not found: {root}")
        return []

    datasets = []

    for path in sorted(root.iterdir()):
        if not path.is_dir():
            continue

        # Only accept directories containing their own trip files.
        trip_id = path.name

        if (
            (path / f"{trip_id}.track").is_file()
            and (path / f"{trip_id}.nodes").is_file()
            and (path / f"{trip_id}.arcs").is_file()
        ):
            datasets.append(path)

    return datasets


def main():
    parser = argparse.ArgumentParser(
        description="Generate consolidated candidate feature CSV files."
    )

    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--dataset",
        type=Path,
        help="Process one dataset directory.",
    )
    mode.add_argument(
        "--all",
        action="store_true",
        help="Process all datasets in train and student_test.",
    )

    parser.add_argument(
        "--radius",
        type=float,
        default=DEFAULT_RADIUS,
        help="Candidate search radius in metres (default: 100).",
    )

    args = parser.parse_args()

    if args.radius <= 0:
        parser.error("--radius must be greater than zero")

    if args.dataset:
        datasets = [args.dataset]
    elif args.all:
        datasets = (
            find_datasets(Path("evaluator_test_collection/evaluator_test"))
        )
    else:
        parser.error("Specify either --dataset or --all")

    if not datasets:
        print("No datasets found.")
        return

    successful = 0
    failed = 0

    for dataset in datasets:
        try:
            enrich_dataset(dataset, args.radius)
            successful += 1
        except Exception as exc:
            failed += 1
            print(f"\n[FAILED] {dataset}: {exc}")

    print("\n========== ENRICHMENT SUMMARY ==========")
    print(f"Successful: {successful}")
    print(f"Failed: {failed}")


if __name__ == "__main__":
    main()
